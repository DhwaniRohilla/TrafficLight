package com.vogella.spring.playground.di;
public interface Beer {
	String getName();
}