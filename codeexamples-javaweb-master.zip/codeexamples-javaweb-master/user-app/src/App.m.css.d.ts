export const root: string;
