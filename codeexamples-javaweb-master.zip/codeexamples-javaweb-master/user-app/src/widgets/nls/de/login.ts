const messages = {
	email: 'E-Mail',
    password: 'Passwort',
    login : 'Anmelden'
};
export default messages;