import de from './de/login';

export default {
	locales: {
		de: () => de
	},
	messages: {
        email: 'Email',
        password: 'Password',
        login : 'Login'
	}
};