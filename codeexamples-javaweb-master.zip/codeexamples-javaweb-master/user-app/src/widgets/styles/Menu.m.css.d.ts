export const root: string;
export const link: string;
export const selected: string;
